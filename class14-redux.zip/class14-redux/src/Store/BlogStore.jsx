
import reducer from './../Reducer/BlogReducer';

const blogReducer = {
    blogs : reducer
}